const { defineConfig } = require('@vue/cli-service')
module.exports = defineConfig({
  transpileDependencies: true,
  // configureWebpack: {
  //   module: {
  //     rules: [
  //       {
  //         test: /\.less$/,
  //         use: 'ignore-loader' // 忽略 .less 文件
  //       }
  //     ]
  //   }
  // },
  css: {
    loaderOptions: {
      less: {
        lessOptions: {
          javascriptEnabled: true // 启用 Less 的 JavaScript 支持
        }
      }
    }
  }
})
