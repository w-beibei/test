import { defineComponent } from 'vue'
import PivotTable from './components/PivotTable'

export default defineComponent({
  name: 'App',
  setup (props, ctx) {
    return () => <PivotTable/>
  }
})
