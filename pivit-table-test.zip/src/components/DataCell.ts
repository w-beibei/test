import { CellBorderPosition, CellClipBox, CellMeta, DataCell, DefaultCellTheme, getBorderPositionAndStyle, getCellBoxByType, InteractionStateName, InteractionStateTheme, renderLine, renderRect, S2CellType, SHAPE_ATTRS_MAP, SHAPE_STYLE_MAP, StateShapeLayer, TextTheme, updateShapeAttr } from '@antv/s2'
import { SimpleBBox } from '@antv/s2/esm/engine'
import {
  find, first, get, isEmpty, isEqual, isObject, merge,
  each,
  includes,
  isArray,
  isBoolean,
  isFunction,
  isNumber,
  keys,
  pickBy,
  sumBy
} from 'lodash'
/**
 * 自定义 DataCell，通过复写基类方法, 给特定单元格设置背景色, 文字大小, 颜色等...
 * 查看更多方法 https://github.com/antvis/S2/blob/next/packages/s2-core/src/cell/data-cell.ts
 * 明细表需要继承 TableDataCell  https://github.com/antvis/S2/blob/next/packages/s2-core/src/cell/table-data-cell.ts
 */
class CustomDataCell extends DataCell {
  initCell () {
    super.initCell()
  }

  isSelected () {
    return this.spreadsheet.interaction.getState().cells.some(cell => cell.id === this.meta.id)
  }

  isHover () {
    return this.spreadsheet.interaction.getState().cells.some(cell => cell.id === this.meta.id)
  }

  //   protected handleHover (cells: CellMeta[]) {
  //     // hover 相关的改动写在这个函数中
  //     const hoverCellMeta = first(cells) as CellMeta
  //     // console.log(this.meta, this.spreadsheet.interaction.getState())
  //     if (this.isDisableHover(hoverCellMeta)) {
  //       this.hideInteractionShape()

  //       return
  //     }

  //     const { currentRow, currentCol } =
  //       this.spreadsheet.interaction.getHoverHighlight()

  //     if (currentRow || currentCol) {
  //       // 如果当前是hover，要绘制出十字交叉的行列样式
  //       const currentColIndex = this.meta.colIndex
  //       const currentRowIndex = this.meta.rowIndex

  //       // 当视图内的 cell 行列 index 与 hover 的 cell 一致，绘制hover的十字样式
  //       if (
  //         (currentCol && currentColIndex === hoverCellMeta?.colIndex) ||
  //         (currentRow && currentRowIndex === hoverCellMeta?.rowIndex)
  //       ) {
  //         this.updateByState(InteractionStateName.HOVER)
  //       } else {
  //         // 当视图内的 cell 行列 index 与 hover 的 cell 不一致，隐藏其他样式
  //         this.hideInteractionShape()
  //       }
  //     }

  //     const { id, rowIndex, colIndex } = this.getMeta()

  //     // fix issue: https://github.com/antvis/S2/issues/1781
  //     if (
  //       isEqual(hoverCellMeta.id, id) &&
  //       isEqual(hoverCellMeta.rowIndex, rowIndex) &&
  //       isEqual(hoverCellMeta.colIndex, colIndex)
  //     ) {
  //       this.updateByState(InteractionStateName.HOVER_FOCUS)
  //     }
  //     if (this.isSelected()) {
  //       console.log(88888888888888)
  //       this.getBackgroundColor()
  //     }
  //   }

  getStyle (name?) {
    // 重写单元格样式
    const defaultCellStyle = super.getStyle(name)
    return defaultCellStyle
  }

  findSelectedValue () {
    if (this.spreadsheet.interaction.getState().interactedCells) {
      const selectCell = this.spreadsheet.interaction.getState().cells[0]
      //   console.log(this.spreadsheet.interaction.getState(), selectCell)
      const selectedColIndex = selectCell?.colIndex
      const selectedRowIndex = selectCell?.rowIndex
      let selectValue = null

      this.spreadsheet.interaction.getState().interactedCells.forEach((item: DataCell) => {
        if (item.position) {
          if (item.position[0] === selectedRowIndex && item.position[1] === selectedColIndex) {
            selectValue = item
          }
        }
      })
      return selectValue
    }
    return null
  }

  public getBBoxByType (type = CellClipBox.BORDER_BOX): SimpleBBox {
    const bbox: SimpleBBox = {
      x: this.meta.x,
      y: this.meta.y,
      height: this.meta.height,
      width: this.meta.width
    }

    const cellStyle = (this.getStyle() ||
      this.theme.dataCell) as DefaultCellTheme

    return getCellBoxByType(
      bbox,
      this.getBorderPositions(),
      cellStyle?.cell,
      type
    )
  }

  drawBorders () {
    console.log(this)
    if (
      this.isSelected()
    ) {
      console.log(this.getStyle()?.cell)

      this.getBorderPositions().forEach((type) => {
        const { position, style } = getBorderPositionAndStyle(
          type,
          this.getBBoxByType(),
          this.getStyle()?.cell
        )

        console.log(style, position)
        style.stroke = 'blue'
        style.lineWidth = 5
        style.zIndex = 9999
        renderLine(this, { ...position, ...style })
      })
    } else {
      this.getBorderPositions().forEach((type) => {
        console.log(type, 77777777777777)

        const { position, style } = getBorderPositionAndStyle(
          type,
          this.getBBoxByType(),
          this.getStyle()?.cell
        )
        renderLine(this, { ...position, ...style })
      })
    }
  }

  //   需要关闭蒙层颜色而不是背景色
  getBackgroundColor () {
    const defaultCellStyle = super.getBackgroundColor()

    // 指定单元格
    if (
      this.isSelected()
    ) {
      console.log(444444444)

      return {
        ...defaultCellStyle,
        backgroundColor: '#e0e9fd'
      }
    }

    const selectTemp = this.findSelectedValue()
    if (
      (this.meta.rowIndex === selectTemp?.position[0] && this.meta.colIndex < selectTemp?.position[1]) || (this.meta.colIndex === selectTemp?.position[1] && this.meta.rowIndex < selectTemp?.position[0])
    ) {
      console.log(this.meta)
      console.log(this.meta.spreadsheet.theme.dataCell.cell.crossBackgroundColor)
      //   #f5f8fe

      return {
        ...defaultCellStyle,
        backgroundColor: 'pink'
        // backgroundColor: this.meta.spreadsheet.theme.dataCell.cell.crossBackgroundColor
      }
    }

    // 创建 S2 实例后绑定事件
    const container = document.querySelector('canvas') // 画布容器

    // 监听画布容器的 mouseleave 事件,目前没有用，后续可以用于鼠标移出清除表格选中数据
    container.addEventListener('mouseleave', () => {
      //   this.spreadsheet.interaction.clearStyleIndependent()
      if (!this.spreadsheet.interaction.getCurrentStateName()) {
        this.spreadsheet.interaction.updateAllDataCells()
      }
      //   console.log(this.spreadsheet.interaction.getCurrentStateName(), 4444444444)
      this.spreadsheet.interaction.clearHoverTimer()
      this.spreadsheet.interaction.resetState()
    })

    return defaultCellStyle
  }

  getTextStyle () {
    const defaultTextStyle = super.getTextStyle()

    // 指定列
    if (this.meta.rowIndex % 2 === 0) {
      return {
        ...defaultTextStyle,
        fontSize: 16,
        fill: '#396',
        textAlign: 'left'
      } as TextTheme
    }

    // 根据不同的事件状态，写不同样式

    // 指定单元格
    if (
      this.isSelected()
    ) {
      return {
        ...defaultTextStyle,
        fontSize: 22,
        fontWeight: 200,
        fill: '#dcdcdc',
        opacity: 0.9,
        textAlign: 'right'
      } as TextTheme
    }

    // 使用默认处理
    return super.getTextStyle()
  }
}

export default CustomDataCell
