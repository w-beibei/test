import { ColCell } from '@antv/s2'

class CustomColCell extends ColCell {
  getStyle (name) {
    // 重写单元格样式
    const defaultCellStyle = super.getStyle(name)
    console.log(defaultCellStyle, '000')

    return defaultCellStyle
  }

  //   getTextStyle () {
  //     const defaultTextStyle = super.getTextStyle()

  //     // 指定列
  //     if (this.meta.colIndex % 2 === 0) {
  //       return {
  //         ...defaultTextStyle,
  //         fontSize: 16,
  //         fill: '#396',
  //         textAlign: 'left'
  //       }
  //     }

  //     // 指定层级
  //     if (this.meta.level >= 1) {
  //       return {
  //         ...defaultTextStyle,
  //         fill: 'pink',
  //         textAlign: 'center'
  //       }
  //     }

  //     // 指定文本
  //     if (this.meta.value === '办公用品') {
  //       return {
  //         ...defaultTextStyle,
  //         fontSize: 22,
  //         textAlign: 'right'
  //       }
  //     }

//     // 使用默认处理
//     return super.getTextStyle()
//   }
}
export default CustomColCell
